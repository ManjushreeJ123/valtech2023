package com.valtech.training.ordersspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
