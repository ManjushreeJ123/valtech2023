package com.valtech.training.empdeptspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpdeptspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
